package com.daril.ujikompetensi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.daril.ujikompetensi.R;

public class EditActivity extends AppCompatActivity {

    private EditText editTextNama, editTextNip, editTextGender, editTextDob, editTextAddress;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editTextNama = findViewById(R.id.editTextNama);
        editTextNip = findViewById(R.id.editTextNip);
        editTextGender = findViewById(R.id.editTextGender);
        editTextDob = findViewById(R.id.editTextDob);
        editTextAddress = findViewById(R.id.editTextAddress);
        Button buttonSave = findViewById(R.id.buttonSave);

        sharedPreferences = getSharedPreferences("BiodataPrefs", Context.MODE_PRIVATE);

        loadBiodata();

        buttonSave.setOnClickListener(v -> {
            saveBiodata();
            Intent intent = new Intent(EditActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void loadBiodata() {
        String nama = sharedPreferences.getString("Nama", "");
        String nip = sharedPreferences.getString("NIP", "");
        String gender = sharedPreferences.getString("Gender", "");
        String dob = sharedPreferences.getString("Dob", "");
        String address = sharedPreferences.getString("Address", "");

        editTextNama.setText(nama);
        editTextNip.setText(nip);
        editTextGender.setText(gender);
        editTextDob.setText(dob);
        editTextAddress.setText(address);
    }

    private void saveBiodata() {
        String nama = editTextNama.getText().toString();
        String nip = editTextNip.getText().toString();
        String gender = editTextGender.getText().toString();
        String dob = editTextDob.getText().toString();
        String address = editTextAddress.getText().toString();

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Nama", nama);
        editor.putString("NIP", nip);
        editor.putString("Gender", gender);
        editor.putString("Dob", dob);
        editor.putString("Address", address);
        editor.apply();
    }
}
