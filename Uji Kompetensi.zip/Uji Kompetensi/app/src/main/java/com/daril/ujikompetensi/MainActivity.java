package com.daril.ujikompetensi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView profileImageView;
    private TextView textViewNip, textViewGender, textViewDob, textViewAddress, textViewNama;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        profileImageView = findViewById(R.id.profileImageView);
        Button buttonChangeImage = findViewById(R.id.buttonChangeImage);
        Button buttonEditBiodata = findViewById(R.id.buttonEditBiodata);
        textViewNama = findViewById(R.id.textViewNama);

        textViewNip = findViewById(R.id.textViewNip);
        textViewGender = findViewById(R.id.textViewGender);
        textViewDob = findViewById(R.id.textViewDob);
        textViewAddress = findViewById(R.id.textViewAddress);

        sharedPreferences = getSharedPreferences("BiodataPrefs", Context.MODE_PRIVATE);

        loadBiodata();

        buttonChangeImage.setOnClickListener(v -> openImageChooser());


        buttonEditBiodata.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditActivity.class);
            startActivity(intent);
        });
    }

    private void loadBiodata() {
        String nama = sharedPreferences.getString("Nama", "Nama Mahasiswa");
        String nip = sharedPreferences.getString("NIP", "N/A");
        String gender = sharedPreferences.getString("Gender", "N/A");
        String dob = sharedPreferences.getString("Dob", "N/A");
        String address = sharedPreferences.getString("Address", "N/A");

        textViewNama.setText(nama);
        textViewNip.setText(nip);
        textViewGender.setText(gender);
        textViewDob.setText(dob);
        textViewAddress.setText(address);

        String profileImageBase64 = sharedPreferences.getString("ProfileImage", "");
        if (!profileImageBase64.isEmpty()) {
            byte[] imageBytes = Base64.getDecoder().decode(profileImageBase64);
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            profileImageView.setImageBitmap(bitmap);
        } else {
            profileImageView.setImageResource(R.drawable.ic_profile_placeholder); // Placeholder image
        }
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                profileImageView.setImageBitmap(bitmap);
                saveProfileImage(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveProfileImage(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] imageBytes = byteArrayOutputStream.toByteArray();
        String imageBase64 = Base64.getEncoder().encodeToString(imageBytes);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("ProfileImage", imageBase64);
        editor.apply();
    }

    private void showEditNamaDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Nama");

        final EditText inputNama = new EditText(this);
        inputNama.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(inputNama);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newNama = inputNama.getText().toString().trim();
            textViewNama.setText(newNama);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("Nama", newNama);
            editor.apply();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}
